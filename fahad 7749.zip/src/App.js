import logo from './logo.svg';
import './App.css';
import Routing from './routing/Routing';

function App() {
  return (
    <div className="App">
      <Routing />
    </div>
  );
}

export default App;
