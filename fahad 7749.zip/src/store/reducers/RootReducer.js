import { combineReducers } from "redux";
import { ItemReducer } from "./ItemReducer";
export const RootReducer = combineReducers({ItemReducer})